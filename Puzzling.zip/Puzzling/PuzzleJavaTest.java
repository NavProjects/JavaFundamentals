public class PuzzleJavaTest {
    public static void main(String[] args) {
        PuzzleJava puzzle = new PuzzleJava();

        // System.out.println(puzzle.tenRolls());
        // System.out.println(puzzle.randLetter());
        // System.out.println(puzzle.generatePassword());
        // System.out.println(puzzle.getNewPassword(15));
    }
}