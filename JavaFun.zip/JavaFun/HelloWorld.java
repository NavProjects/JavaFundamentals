public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("My name is John Doe I am 26 years old My hometown is Los Angeles CA");
    }
}